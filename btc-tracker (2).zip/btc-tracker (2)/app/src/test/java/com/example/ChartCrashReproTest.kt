package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.example.data.model.CandleStick
import com.example.data.model.Trade
import com.example.data.model.TradeSide
import com.example.ui.components.Btc1MinCandlestickChart
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChartCrashReproTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun testChartRendersWithoutCrashWhenEmpty() {
        composeRule.setContent {
            Btc1MinCandlestickChart(
                candles = emptyList(),
                trades = emptyList(),
                currentPrice = null,
                isLoading = false
            )
        }
        composeRule.onNodeWithTag("candlestick_chart_container").assertExists()
    }

    @Test
    fun testChartRendersWithSampleCandlesAndTrades() {
        val nowSec = System.currentTimeMillis() / 1000
        val sampleCandles = listOf(
            CandleStick(nowSec - 120, 60000.0, 60100.0, 60150.0, 59950.0, 10.0, 600000.0),
            CandleStick(nowSec - 60, 60100.0, 60050.0, 60200.0, 60000.0, 15.0, 900000.0),
            CandleStick(nowSec, 60050.0, 60300.0, 60350.0, 60020.0, 20.0, 1200000.0)
        )
        val sampleTrades = listOf(
            Trade("1", 60120.0, 0.25, TradeSide.BUY, System.currentTimeMillis() - 30000, false),
            Trade("2", 60110.0, 0.45, TradeSide.SELL, System.currentTimeMillis() - 10000, false),
            Trade("3", 60250.0, 1.5, TradeSide.BUY, System.currentTimeMillis() - 5000, true)
        )

        composeRule.setContent {
            Btc1MinCandlestickChart(
                candles = sampleCandles,
                trades = sampleTrades,
                currentPrice = 60300.0,
                isLoading = false
            )
        }
        composeRule.onNodeWithTag("candlestick_chart_container").assertExists()
    }
}
