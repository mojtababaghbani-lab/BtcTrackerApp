package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ConnectionStatus
import com.example.data.model.OrderBookData
import com.example.data.model.Trade
import com.example.data.model.TradeSide
import com.example.ui.components.Btc1MinCandlestickChart
import com.example.ui.components.OrderBookFullTable
import com.example.ui.components.WhaleAlertBanner
import com.example.ui.theme.BtcOrange
import com.example.ui.theme.BuyGreen
import com.example.ui.theme.ConnectedGreen
import com.example.ui.theme.ConnectingAmber
import com.example.ui.theme.CryptoBg
import com.example.ui.theme.CryptoCardBorder
import com.example.ui.theme.CryptoSurface
import com.example.ui.theme.CryptoSurfaceVariant
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SellRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhaleGold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BtcTraderScreen(
    viewModel: BtcTraderViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val allTradesListState = rememberLazyListState()
    val whaleTradesListState = rememberLazyListState()

    // Automatically snap to top when new trades arrive so the user always sees the newest trade first
    LaunchedEffect(uiState.recentTrades.firstOrNull()?.id) {
        if (uiState.recentTrades.isNotEmpty() && !allTradesListState.isScrollInProgress) {
            allTradesListState.scrollToItem(0)
        }
    }

    LaunchedEffect(uiState.whaleTrades.firstOrNull()?.id) {
        if (uiState.whaleTrades.isNotEmpty() && !whaleTradesListState.isScrollInProgress) {
            whaleTradesListState.scrollToItem(0)
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("btc_trader_screen"),
        containerColor = CryptoBg,
        topBar = {
            TraderCompactTopBar(
                selectedSymbol = uiState.selectedSymbol,
                connectionStatus = uiState.connectionStatus,
                isRefreshing = uiState.isRefreshing,
                isSoundEnabled = uiState.isSoundEnabled,
                isVibrateEnabled = uiState.isVibrateEnabled,
                isBackgroundEnabled = uiState.isBackgroundEnabled,
                onToggleSound = viewModel::toggleSound,
                onToggleVibrate = viewModel::toggleVibration,
                onToggleBackground = viewModel::toggleBackgroundMode,
                onTestSound = viewModel::testSoundAlert,
                onManualRefresh = viewModel::manualRefresh
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Multi-Coin Symbol Chips Selector (BTC, ETH, SOL, BNB, ADA, XRP)
            SymbolChipsRow(
                selectedSymbol = uiState.selectedSymbol,
                symbols = uiState.availableSymbols,
                onSelectSymbol = viewModel::selectSymbol
            )

            // Whale Alert Banner (if active)
            WhaleAlertBanner(
                whaleTrade = uiState.activeWhaleAlert,
                onDismiss = viewModel::dismissWhaleBanner
            )

            // Compact Market Card (Price + Bid/Ask Ratio + Volume Depth)
            UnifiedMarketCard(
                symbolName = uiState.selectedSymbol,
                currentPrice = uiState.currentPrice,
                priceDirection = uiState.priceDirection,
                orderBook = uiState.orderBook
            )

            val filteredRecentTrades = remember(uiState.recentTrades) {
                uiState.recentTrades.filter { it.size >= 0.01 }
            }
            val filteredWhaleTrades = remember(uiState.whaleTrades) {
                uiState.whaleTrades.filter { it.size >= 0.1 }
            }

            // Tabs for All Trades / Whale Alerts / 1-Min Chart / Order Book
            TraderCompactTabRow(
                selectedTab = uiState.selectedTab,
                allTradesCount = filteredRecentTrades.size,
                whaleTradesCount = filteredWhaleTrades.size,
                onSelectTab = viewModel::selectTab
            )

            // Main Content Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (uiState.selectedTab) {
                    TraderTab.ALL_TRADES -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            TradeTableHeader()
                            if (filteredRecentTrades.isEmpty()) {
                                EmptyTradesPlaceholder(
                                    message = "در حال دریافت معاملات زنده بالای ۰.۰۱ از بایننس..."
                                )
                            } else {
                                LazyColumn(
                                    state = allTradesListState,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("all_trades_list")
                                ) {
                                    itemsIndexed(
                                        items = filteredRecentTrades,
                                        key = { index: Int, trade: Trade -> "${trade.id}_${trade.timestamp}_$index" }
                                    ) { _, trade: Trade ->
                                        TradeItemRow(trade = trade)
                                    }
                                }
                            }
                        }
                    }

                    TraderTab.WHALE_ALERTS -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            TradeTableHeader()
                            if (filteredWhaleTrades.isEmpty()) {
                                EmptyTradesPlaceholder(
                                    message = "معامله‌ای با حجم ۰.۱ یا بالاتر ثبت نشده است.\nبه محض انجام معامله بزرگ با هشدار صوتی و اعلان پس‌زمینه اعلام خواهد شد."
                                )
                            } else {
                                LazyColumn(
                                    state = whaleTradesListState,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("whale_trades_list")
                                ) {
                                    itemsIndexed(
                                        items = filteredWhaleTrades,
                                        key = { index: Int, trade: Trade -> "${trade.id}_${trade.timestamp}_$index" }
                                    ) { _, trade: Trade ->
                                        TradeItemRow(trade = trade)
                                    }
                                }
                            }
                        }
                    }

                    TraderTab.CHART -> {
                        Btc1MinCandlestickChart(
                            candles = uiState.candleSticks,
                            trades = uiState.recentTrades,
                            currentPrice = uiState.currentPrice,
                            isLoading = uiState.isCandlesLoading,
                            modifier = Modifier.fillMaxSize(),
                            symbolName = uiState.selectedSymbol
                        )
                    }

                    TraderTab.ORDER_BOOK -> {
                        OrderBookFullTable(orderBook = uiState.orderBook)
                    }
                }
            }
        }
    }
}

@Composable
private fun SymbolChipsRow(
    selectedSymbol: String,
    symbols: List<String>,
    onSelectSymbol: (String) -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(CryptoSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(symbols) { sym ->
                val isSelected = sym == selectedSymbol
                val coinName = sym.replace("USDT", "")
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) BtcOrange else CryptoSurfaceVariant)
                        .border(
                            1.dp,
                            if (isSelected) BtcOrange else CryptoCardBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelectSymbol(sym) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = coinName,
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "/USDT",
                            color = if (isSelected) Color.Black.copy(alpha = 0.7f) else TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TraderCompactTopBar(
    selectedSymbol: String,
    connectionStatus: ConnectionStatus,
    isRefreshing: Boolean,
    isSoundEnabled: Boolean,
    isVibrateEnabled: Boolean,
    isBackgroundEnabled: Boolean,
    onToggleSound: () -> Unit,
    onToggleVibrate: () -> Unit,
    onToggleBackground: () -> Unit,
    onTestSound: () -> Unit,
    onManualRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .background(CryptoSurface)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Symbol Logo + Connection Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(BtcOrange),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (selectedSymbol.startsWith("BTC")) "₿" else selectedSymbol.take(1),
                        color = Color.Black,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = selectedSymbol,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(CryptoSurfaceVariant)
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "Spot v2.3",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(BtcOrange.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "≥ ۰.۰۱",
                                color = BtcOrange,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // WebSocket status
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val (dotColor, label) = when (connectionStatus) {
                            ConnectionStatus.CONNECTED -> ConnectedGreen to "WS زنده"
                            ConnectionStatus.CONNECTING -> ConnectingAmber to "اتصال..."
                            ConnectionStatus.RECONNECTING -> ConnectingAmber to "تلاش مجدد..."
                            ConnectionStatus.OFFLINE -> ErrorRed to "قطع"
                        }
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                        )
                        Text(
                            text = label,
                            color = dotColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Right: Background Mode Toggle + Sound + Vibration + Refresh
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Background execution badge button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isBackgroundEnabled) ConnectedGreen.copy(alpha = 0.15f) else CryptoSurfaceVariant)
                        .border(
                            1.dp,
                            if (isBackgroundEnabled) ConnectedGreen else CryptoCardBorder,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable(onClick = onToggleBackground)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isBackgroundEnabled) "🟢 پس‌زمینه فعال" else "⚪ پس‌زمینه خاموش",
                        color = if (isBackgroundEnabled) ConnectedGreen else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Sound Toggle
                IconButton(
                    onClick = onToggleSound,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("sound_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.NotificationsOff,
                        contentDescription = "Sound Toggle",
                        tint = if (isSoundEnabled) BtcOrange else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Vibration Toggle
                IconButton(
                    onClick = onToggleVibrate,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("vibrate_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Vibration Toggle",
                        tint = if (isVibrateEnabled) ConnectedGreen else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Test Tone Button
                IconButton(
                    onClick = onTestSound,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Test Alert Tone",
                        tint = WhaleGold,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Refresh Button
                IconButton(
                    onClick = onManualRefresh,
                    modifier = Modifier.size(32.dp)
                ) {
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = BtcOrange,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UnifiedMarketCard(
    symbolName: String,
    currentPrice: Double?,
    priceDirection: Int,
    orderBook: OrderBookData?,
    modifier: Modifier = Modifier
) {
    val priceColor = when (priceDirection) {
        1 -> BuyGreen
        -1 -> SellRed
        else -> TextPrimary
    }

    val arrowIcon = when (priceDirection) {
        1 -> "▲"
        -1 -> "▼"
        else -> "•"
    }

    val bestBid = orderBook?.bestBid ?: 0.0
    val bestAsk = orderBook?.bestAsk ?: 0.0
    val totalBidVol = orderBook?.totalBidVolume ?: 0.0
    val totalAskVol = orderBook?.totalAskVolume ?: 0.0
    val totalVol = totalBidVol + totalAskVol
    val bidRatio = if (totalVol > 0) (totalBidVol / totalVol).toFloat() else 0.5f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(CryptoSurface)
            .border(1.dp, CryptoCardBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Live Price with Arrow
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (currentPrice != null) String.format(Locale.US, "$%,.2f", currentPrice) else "$--,--",
                            color = priceColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = arrowIcon,
                            color = priceColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Best Bid & Ask
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "بهترین خرید (Bid)", color = TextMuted, fontSize = 9.sp)
                            Text(
                                text = if (bestBid > 0) String.format(Locale.US, "$%,.2f", bestBid) else "-",
                                color = BuyGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "بهترین فروش (Ask)", color = TextMuted, fontSize = 9.sp)
                            Text(
                                text = if (bestAsk > 0) String.format(Locale.US, "$%,.2f", bestAsk) else "-",
                                color = SellRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Buyer vs Seller Volume Ratio Depth Bar (Visual Order Book Ratio)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val buyerPercent = (bidRatio * 100).toInt()
                        val sellerPercent = ((1f - bidRatio) * 100).toInt()
                        Text(
                            text = "خریداران: $buyerPercent% (" + String.format(Locale.US, "%.1f", totalBidVol) + ")",
                            color = BuyGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "فروشندگان: $sellerPercent% (" + String.format(Locale.US, "%.1f", totalAskVol) + ")",
                            color = SellRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Progress bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(bidRatio.coerceIn(0.05f, 0.95f))
                                .fillMaxSize()
                                .background(BuyGreen)
                        )
                        Box(
                            modifier = Modifier
                                .weight((1f - bidRatio).coerceIn(0.05f, 0.95f))
                                .fillMaxSize()
                                .background(SellRed)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TraderCompactTabRow(
    selectedTab: TraderTab,
    allTradesCount: Int,
    whaleTradesCount: Int,
    onSelectTab: (TraderTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(CryptoSurface)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        TabItem(
            text = "معاملات ≥ ۰.۰۱ ($allTradesCount)",
            icon = Icons.Default.List,
            isSelected = selectedTab == TraderTab.ALL_TRADES,
            onClick = { onSelectTab(TraderTab.ALL_TRADES) },
            modifier = Modifier.weight(1f)
        )
        TabItem(
            text = "نهنگ‌ها ($whaleTradesCount)",
            icon = Icons.Default.ShowChart,
            isSelected = selectedTab == TraderTab.WHALE_ALERTS,
            onClick = { onSelectTab(TraderTab.WHALE_ALERTS) },
            modifier = Modifier.weight(1f),
            badgeColor = WhaleGold
        )
        TabItem(
            text = "چارت ۱دقیقه",
            icon = Icons.Default.CandlestickChart,
            isSelected = selectedTab == TraderTab.CHART,
            onClick = { onSelectTab(TraderTab.CHART) },
            modifier = Modifier.weight(1f)
        )
        TabItem(
            text = "دفتر سفارش",
            icon = Icons.Default.TableChart,
            isSelected = selectedTab == TraderTab.ORDER_BOOK,
            onClick = { onSelectTab(TraderTab.ORDER_BOOK) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun TabItem(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeColor: Color = BtcOrange
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CryptoSurfaceVariant else Color.Transparent)
            .border(
                1.dp,
                if (isSelected) badgeColor else Color.Transparent,
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) badgeColor else TextMuted,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = text,
                color = if (isSelected) TextPrimary else TextMuted,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TradeTableHeader() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CryptoSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "قیمت (USDT)", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(text = "حجم (≥ ۰.۰۱)", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(text = "زمان", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun TradeItemRow(trade: Trade) {
    val isBuy = trade.side == TradeSide.BUY
    val color = if (isBuy) BuyGreen else SellRed
    val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(trade.timestamp))

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (trade.isWhale) WhaleGold.copy(alpha = 0.08f) else Color.Transparent)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Price + Side
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(color)
                )
                Text(
                    text = String.format(Locale.US, "$%,.2f", trade.price),
                    color = color,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Size
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = String.format(Locale.US, "%.4f", trade.size),
                    color = if (trade.isWhale) WhaleGold else TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = if (trade.isWhale) FontWeight.ExtraBold else FontWeight.Medium,
                    fontFamily = FontFamily.Monospace
                )
                if (trade.isWhale) {
                    Text(text = "🐋", fontSize = 11.sp)
                }
            }

            // Time
            Text(
                text = timeFmt,
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun EmptyTradesPlaceholder(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(
                color = BtcOrange,
                modifier = Modifier.size(32.dp),
                strokeWidth = 2.5.dp
            )
            Text(
                text = message,
                color = TextMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
