package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CryptoDarkColorScheme = darkColorScheme(
    primary = BtcOrange,
    onPrimary = TextPrimary,
    primaryContainer = CryptoSurfaceVariant,
    onPrimaryContainer = BtcOrange,
    secondary = BuyGreen,
    onSecondary = CryptoBg,
    secondaryContainer = BuyGreenSurface,
    onSecondaryContainer = BuyGreen,
    tertiary = WhaleGold,
    onTertiary = CryptoBg,
    tertiaryContainer = WhaleGoldSurface,
    onTertiaryContainer = WhaleGold,
    background = CryptoBg,
    onBackground = TextPrimary,
    surface = CryptoSurface,
    onSurface = TextPrimary,
    surfaceVariant = CryptoSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CryptoCardBorder,
    error = SellRed,
    onError = TextPrimary,
    errorContainer = SellRedSurface,
    onErrorContainer = SellRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CryptoDarkColorScheme,
        typography = Typography,
        content = content
    )
}
