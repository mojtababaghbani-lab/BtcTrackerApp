package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.TradeSide
import com.example.data.network.BinanceRepository
import com.example.sound.SoundAlertManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Foreground Service that keeps the live crypto market connection and large-trade alerts
 * running smoothly even when the app is minimized or the screen is turned off.
 */
class LiveMarketForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "live_crypto_tracker_channel"
        const val ALERTS_CHANNEL_ID = "live_crypto_alerts_channel"
        const val NOTIFICATION_ID = 1010
        const val ALERT_NOTIFICATION_ID = 1011
        const val ACTION_START = "ACTION_START_TRACKER"
        const val ACTION_STOP = "ACTION_STOP_TRACKER"

        private val _isRunning = MutableStateFlow(false)
        val isRunning = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, LiveMarketForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, LiveMarketForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var soundManager: SoundAlertManager
    private val repository = BinanceRepository.getInstance()

    private var currentPrice: Double = 0.0
    private var lastLargeTradeInfo: String = "در حال نظارت..."
    private var tradeCollectJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        soundManager = SoundAlertManager(applicationContext)
        createNotificationChannel()

        // Acquire partial wakelock to ensure socket stays alive while minimized
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "BtcTracker::BackgroundSyncWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(24 * 60 * 60 * 1000L) // 24 hours max safety timeout
            }
        } catch (e: Exception) {
            Log.e("ForegroundService", "Error acquiring WakeLock", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForegroundService()
            return START_NOT_STICKY
        }

        startForegroundWithNotification()
        _isRunning.value = true

        startCollectingTrades()

        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification(
            title = "🟢 ردیاب زنده ${repository.getCurrentSymbol()}",
            content = "برنامه در حالت مینی‌مایز فعال است و معاملات بررسی می‌شوند."
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private var lastNotificationUpdateTime = 0L

    private fun startCollectingTrades() {
        tradeCollectJob?.cancel()
        tradeCollectJob = serviceScope.launch {
            repository.tradeFlow.collect { trade ->
                currentPrice = trade.price
                val isBuy = trade.side == TradeSide.BUY
                val sideText = if (isBuy) "خرید 🟢" else "فروش 🔴"

                // Check for large trade / whale (>= 0.1 BTC)
                if (trade.size >= 0.1) {
                    lastLargeTradeInfo = String.format(
                        Locale.US,
                        "🚨 %s: %.3f در $%,.2f",
                        sideText,
                        trade.size,
                        trade.price
                    )
                    // Play sound and vibration in background
                    soundManager.playWhaleAlert(vibrate = true)

                    // Post a high-priority heads-up alert notification
                    sendWhaleAlertNotification(
                        title = "🚨 شکار نهنگ ${repository.getCurrentSymbol()}!",
                        content = lastLargeTradeInfo
                    )
                }

                // Update ongoing status notification at most once every 3 seconds to preserve battery
                val now = System.currentTimeMillis()
                if (now - lastNotificationUpdateTime >= 3000L) {
                    lastNotificationUpdateTime = now
                    val text = String.format(
                        Locale.US,
                        "قیمت: $%,.2f | آخرین: %.3f (%s)",
                        currentPrice,
                        trade.size,
                        sideText
                    )
                    updateNotification(
                        title = "🟢 ردیاب فعال ${repository.getCurrentSymbol()}",
                        content = text
                    )
                }
            }
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun sendWhaleAlertNotification(title: String, content: String) {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Use standard notification sound and vibration pattern for lockscreen/heads-up banner
        val alertNotification = NotificationCompat.Builder(this, ALERTS_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setFullScreenIntent(pendingIntent, false) // Enables heads-up banner on home screen
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Visible on lock screen
            .setPriority(NotificationCompat.PRIORITY_MAX) // Heads-up display
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVibrate(longArrayOf(0, 350, 150, 350))
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_LIGHTS)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(ALERT_NOTIFICATION_ID, alertNotification)
    }

    private fun updateNotification(title: String, content: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val statusChannel = NotificationChannel(
                CHANNEL_ID,
                "ردیاب بازار ارز دیجیتال (وضعیت مداوم)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "نمایش قیمت لحظه‌ای در زمان مینی‌مایز بودن برنامه"
                setShowBadge(false)
            }
            manager.createNotificationChannel(statusChannel)

            val alertsChannel = NotificationChannel(
                ALERTS_CHANNEL_ID,
                "هشدارهای معاملات بزرگ و نهنگ‌ها",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ارسال اعلان و هشدار صوتی هنگام انجام معاملات سنگین"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 150, 350)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setShowBadge(true)
            }
            manager.createNotificationChannel(alertsChannel)
        }
    }

    private fun stopForegroundService() {
        _isRunning.value = false
        tradeCollectJob?.cancel()
        serviceScope.cancel()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            Log.e("ForegroundService", "Error releasing WakeLock", e)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopForegroundService()
        soundManager.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
