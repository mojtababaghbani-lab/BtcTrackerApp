package com.example.data.network

import android.util.Log
import com.example.data.model.CandleStick
import com.example.data.model.ConnectionStatus
import com.example.data.model.OrderBookData
import com.example.data.model.OrderBookEntry
import com.example.data.model.Trade
import com.example.data.model.TradeSide
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * High-performance Binance Spot WebSocket & REST Repository.
 *
 * Provides real-time trade stream, 1-minute candlestick data, and order book depth.
 * Supports multi-coin tracking (BTC, ETH, SOL, BNB, ADA, XRP) and background operation.
 */
class BinanceRepository private constructor() {

    companion object {
        @Volatile
        private var INSTANCE: BinanceRepository? = null

        fun getInstance(): BinanceRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BinanceRepository().also { INSTANCE = it }
            }
        }

        val AVAILABLE_SYMBOLS = listOf("BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "ADAUSDT", "XRPUSDT")
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private var activeWebSocket: WebSocket? = null
    private var currentSymbol: String = "BTCUSDT"

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.OFFLINE)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _tradeFlow = MutableSharedFlow<Trade>(
        extraBufferCapacity = 128,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val tradeFlow: SharedFlow<Trade> = _tradeFlow.asSharedFlow()

    private val _latestPrice = MutableStateFlow<Double?>(null)
    val latestPrice: StateFlow<Double?> = _latestPrice.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO)
    private var reconnectJob: Job? = null
    private var shouldReconnect = true

    fun getCurrentSymbol(): String = currentSymbol

    fun connectTradeWebSocket(symbol: String) {
        currentSymbol = symbol.uppercase()
        shouldReconnect = true
        closeWebSocket()

        _connectionStatus.value = ConnectionStatus.CONNECTING
        val lowerSymbol = currentSymbol.lowercase()
        val url = "wss://stream.bybit.com/v5/public/spot"

        val request = Request.Builder()
            .url(url)
            .build()

        activeWebSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.d("BinanceRepository", "Bybit WebSocket connected for $symbol")
                _connectionStatus.value = ConnectionStatus.CONNECTED
                val subMsg = JSONObject().apply {
                    put("op", "subscribe")
                    put("args", JSONArray().apply {
                        put("publicTrade.${symbol.uppercase()}")
                    })
                }
                webSocket.send(subMsg.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    // Bybit trade payload format: {"topic":"publicTrade.BTCUSDT","data":[{"i":"...","T":...,"p":"...","v":"...","S":"Buy"}]}
                    val topic = json.optString("topic")
                    if (topic.startsWith("publicTrade")) {
                        val dataArray = json.optJSONArray("data") ?: return
                        for (i in 0 until dataArray.length()) {
                            val item = dataArray.optJSONObject(i) ?: continue
                            val price = item.optString("p", "0").toDoubleOrNull() ?: 0.0
                            val qty = item.optString("v", "0").toDoubleOrNull() ?: 0.0
                            val sideStr = item.optString("S")
                            val timestamp = item.optLong("T", System.currentTimeMillis())
                            val tradeId = item.optString("i", UUID.randomUUID().toString())

                            if (price > 0 && qty > 0) {
                                val side = if (sideStr.equals("Buy", ignoreCase = true)) TradeSide.BUY else TradeSide.SELL
                                val trade = Trade(
                                    id = tradeId,
                                    price = price,
                                    size = qty,
                                    side = side,
                                    timestamp = timestamp,
                                    isWhale = qty >= 0.1
                                )
                                _latestPrice.value = price
                                _tradeFlow.tryEmit(trade)
                            }
                        }
                    } else if (json.optString("e") == "trade") {
                        // Support Binance format if connected to Binance
                        val price = json.optString("p", "0").toDoubleOrNull() ?: 0.0
                        val qty = json.optString("q", "0").toDoubleOrNull() ?: 0.0
                        val isBuyerMaker = json.optBoolean("m", false)
                        val timestamp = json.optLong("T", System.currentTimeMillis())
                        val tradeId = json.optString("t", UUID.randomUUID().toString())

                        if (price > 0 && qty > 0) {
                            val side = if (isBuyerMaker) TradeSide.SELL else TradeSide.BUY
                            val trade = Trade(
                                id = tradeId,
                                price = price,
                                size = qty,
                                side = side,
                                timestamp = timestamp,
                                isWhale = qty >= 0.1
                            )
                            _latestPrice.value = price
                            _tradeFlow.tryEmit(trade)
                        }
                    }
                } catch (e: Exception) {
                    Log.e("BinanceRepository", "Error parsing trade event", e)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e("BinanceRepository", "WebSocket failure for $symbol: ${t.message}")
                _connectionStatus.value = ConnectionStatus.OFFLINE
                scheduleReconnect()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.d("BinanceRepository", "WebSocket closed: $code / $reason")
                _connectionStatus.value = ConnectionStatus.OFFLINE
                scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (!shouldReconnect) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            _connectionStatus.value = ConnectionStatus.RECONNECTING
            delay(3000)
            if (shouldReconnect) {
                connectTradeWebSocket(currentSymbol)
            }
        }
    }

    fun closeWebSocket() {
        shouldReconnect = false
        reconnectJob?.cancel()
        try {
            activeWebSocket?.close(1000, "Normal closure")
        } catch (e: Exception) {
            // ignore
        }
        activeWebSocket = null
    }

    suspend fun fetchPrice(symbol: String = currentSymbol): Result<Double> = withContext(Dispatchers.IO) {
        // Try Binance first
        try {
            val url = "https://api.binance.com/api/v3/ticker/price?symbol=${symbol.uppercase()}"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val json = JSONObject(body)
                        val price = json.optString("price", "0").toDoubleOrNull() ?: 0.0
                        if (price > 0) {
                            _latestPrice.value = price
                            return@withContext Result.success(price)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("BinanceRepository", "Binance fetchPrice failed, trying Bybit: ${e.message}")
        }

        // Fallback to Bybit
        try {
            val url = "https://api.bybit.com/v5/market/tickers?category=spot&symbol=${symbol.uppercase()}"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val json = JSONObject(body)
                        val list = json.optJSONObject("result")?.optJSONArray("list")
                        val item = list?.optJSONObject(0)
                        val price = item?.optString("lastPrice", "0")?.toDoubleOrNull() ?: 0.0
                        if (price > 0) {
                            _latestPrice.value = price
                            return@withContext Result.success(price)
                        }
                    }
                }
                Result.failure(IOException("Failed to fetch price from both exchanges"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchOrderBook(symbol: String = currentSymbol): Result<OrderBookData> = withContext(Dispatchers.IO) {
        // Try Binance first
        try {
            val url = "https://api.binance.com/api/v3/depth?symbol=${symbol.uppercase()}&limit=100"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val json = JSONObject(body)
                        val lastUpdateId = json.optLong("lastUpdateId", 0L).toString()
                        val bidsArray = json.optJSONArray("bids") ?: JSONArray()
                        val asksArray = json.optJSONArray("asks") ?: JSONArray()

                        val bids = ArrayList<OrderBookEntry>()
                        for (i in 0 until bidsArray.length()) {
                            val item = bidsArray.optJSONArray(i) ?: continue
                            val price = item.optString(0, "0").toDoubleOrNull() ?: 0.0
                            val size = item.optString(1, "0").toDoubleOrNull() ?: 0.0
                            if (price > 0 && size > 0) bids.add(OrderBookEntry(price, size))
                        }

                        val asks = ArrayList<OrderBookEntry>()
                        for (i in 0 until asksArray.length()) {
                            val item = asksArray.optJSONArray(i) ?: continue
                            val price = item.optString(0, "0").toDoubleOrNull() ?: 0.0
                            val size = item.optString(1, "0").toDoubleOrNull() ?: 0.0
                            if (price > 0 && size > 0) asks.add(OrderBookEntry(price, size))
                        }

                        if (bids.isNotEmpty() || asks.isNotEmpty()) {
                            val totalBidVolume = bids.sumOf { it.size }
                            val totalAskVolume = asks.sumOf { it.size }
                            val bestBid = bids.firstOrNull()?.price ?: 0.0
                            val bestAsk = asks.firstOrNull()?.price ?: 0.0
                            val spread = if (bestAsk > 0 && bestBid > 0) (bestAsk - bestBid) else 0.0
                            val midPrice = if (bestAsk > 0 && bestBid > 0) (bestAsk + bestBid) / 2.0 else bestBid

                            return@withContext Result.success(
                                OrderBookData(
                                    sequence = lastUpdateId,
                                    timestamp = System.currentTimeMillis(),
                                    bids = bids,
                                    asks = asks,
                                    totalBidVolume = totalBidVolume,
                                    totalAskVolume = totalAskVolume,
                                    bestBid = bestBid,
                                    bestAsk = bestAsk,
                                    spread = spread,
                                    midPrice = midPrice
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("BinanceRepository", "Binance fetchOrderBook failed, trying Bybit: ${e.message}")
        }

        // Fallback to Bybit OrderBook
        try {
            val url = "https://api.bybit.com/v5/market/orderbook?category=spot&symbol=${symbol.uppercase()}&limit=50"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("HTTP Error ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.failure(IOException("Empty body"))
                val json = JSONObject(body)
                val resultObj = json.optJSONObject("result") ?: JSONObject()

                val seq = resultObj.optLong("seq", System.currentTimeMillis()).toString()
                val bidsArray = resultObj.optJSONArray("b") ?: JSONArray()
                val asksArray = resultObj.optJSONArray("a") ?: JSONArray()

                val bids = ArrayList<OrderBookEntry>()
                for (i in 0 until bidsArray.length()) {
                    val item = bidsArray.optJSONArray(i) ?: continue
                    val price = item.optString(0, "0").toDoubleOrNull() ?: 0.0
                    val size = item.optString(1, "0").toDoubleOrNull() ?: 0.0
                    if (price > 0 && size > 0) bids.add(OrderBookEntry(price, size))
                }

                val asks = ArrayList<OrderBookEntry>()
                for (i in 0 until asksArray.length()) {
                    val item = asksArray.optJSONArray(i) ?: continue
                    val price = item.optString(0, "0").toDoubleOrNull() ?: 0.0
                    val size = item.optString(1, "0").toDoubleOrNull() ?: 0.0
                    if (price > 0 && size > 0) asks.add(OrderBookEntry(price, size))
                }

                val totalBidVolume = bids.sumOf { it.size }
                val totalAskVolume = asks.sumOf { it.size }
                val bestBid = bids.firstOrNull()?.price ?: 0.0
                val bestAsk = asks.firstOrNull()?.price ?: 0.0
                val spread = if (bestAsk > 0 && bestBid > 0) (bestAsk - bestBid) else 0.0
                val midPrice = if (bestAsk > 0 && bestBid > 0) (bestAsk + bestBid) / 2.0 else bestBid

                Result.success(
                    OrderBookData(
                        sequence = seq,
                        timestamp = System.currentTimeMillis(),
                        bids = bids,
                        asks = asks,
                        totalBidVolume = totalBidVolume,
                        totalAskVolume = totalAskVolume,
                        bestBid = bestBid,
                        bestAsk = bestAsk,
                        spread = spread,
                        midPrice = midPrice
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetch1MinCandles(symbol: String = currentSymbol): Result<List<CandleStick>> = withContext(Dispatchers.IO) {
        // Try Binance first
        try {
            val url = "https://api.binance.com/api/v3/klines?symbol=${symbol.uppercase()}&interval=1m&limit=80"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val dataArray = JSONArray(body)
                        val list = ArrayList<CandleStick>()

                        for (i in 0 until dataArray.length()) {
                            val kline = dataArray.optJSONArray(i) ?: continue
                            val openTimeMs = kline.optLong(0, 0L)
                            val timeSec = openTimeMs / 1000L
                            val open = kline.optString(1, "0").toDoubleOrNull() ?: 0.0
                            val high = kline.optString(2, "0").toDoubleOrNull() ?: 0.0
                            val low = kline.optString(3, "0").toDoubleOrNull() ?: 0.0
                            val close = kline.optString(4, "0").toDoubleOrNull() ?: 0.0
                            val volume = kline.optString(5, "0").toDoubleOrNull() ?: 0.0
                            val turnover = kline.optString(7, "0").toDoubleOrNull() ?: 0.0

                            if (open > 0 && close > 0 && high > 0 && low > 0) {
                                list.add(
                                    CandleStick(
                                        time = timeSec,
                                        open = open,
                                        close = close,
                                        high = high,
                                        low = low,
                                        volume = volume,
                                        turnover = turnover
                                    )
                                )
                            }
                        }

                        if (list.isNotEmpty()) {
                            list.sortBy { it.time }
                            return@withContext Result.success(list)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("BinanceRepository", "Binance fetch1MinCandles failed, trying Bybit: ${e.message}")
        }

        // Fallback to Bybit 1-min klines
        try {
            val url = "https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol.uppercase()}&interval=1&limit=80"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("HTTP Error ${response.code}"))
                }
                val body = response.body?.string() ?: return@withContext Result.failure(IOException("Empty body"))
                val json = JSONObject(body)
                val dataArray = json.optJSONObject("result")?.optJSONArray("list") ?: JSONArray()
                val list = ArrayList<CandleStick>()

                // Bybit Kline item: [startTime, openPrice, highPrice, lowPrice, closePrice, volume, turnover]
                for (i in 0 until dataArray.length()) {
                    val kline = dataArray.optJSONArray(i) ?: continue
                    val openTimeMs = kline.optLong(0, 0L)
                    val timeSec = openTimeMs / 1000L
                    val open = kline.optString(1, "0").toDoubleOrNull() ?: 0.0
                    val high = kline.optString(2, "0").toDoubleOrNull() ?: 0.0
                    val low = kline.optString(3, "0").toDoubleOrNull() ?: 0.0
                    val close = kline.optString(4, "0").toDoubleOrNull() ?: 0.0
                    val volume = kline.optString(5, "0").toDoubleOrNull() ?: 0.0
                    val turnover = kline.optString(6, "0").toDoubleOrNull() ?: 0.0

                    if (open > 0 && close > 0 && high > 0 && low > 0) {
                        list.add(
                            CandleStick(
                                time = timeSec,
                                open = open,
                                close = close,
                                high = high,
                                low = low,
                                volume = volume,
                                turnover = turnover
                            )
                        )
                    }
                }

                list.sortBy { it.time }
                Result.success(list)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
