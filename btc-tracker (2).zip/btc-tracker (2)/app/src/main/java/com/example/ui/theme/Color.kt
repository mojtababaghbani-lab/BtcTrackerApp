package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Crypto Trading Dark Palette
val CryptoBg = Color(0xFF0A0E17)
val CryptoSurface = Color(0xFF131926)
val CryptoSurfaceVariant = Color(0xFF1B2335)
val CryptoCardBorder = Color(0xFF263248)

val BtcOrange = Color(0xFFF7931A)
val BtcOrangeDark = Color(0xFFC8710B)

val BuyGreen = Color(0xFF00E676)
val BuyGreenDim = Color(0xFF00B050)
val BuyGreenSurface = Color(0x1F00E676)

val SellRed = Color(0xFFFF5252)
val SellRedDim = Color(0xFFD32F2F)
val SellRedSurface = Color(0x1FFF5252)

val WhaleGold = Color(0xFFFFD700)
val WhaleGoldSurface = Color(0x28FFD700)

val TradeYellow = Color(0xFFFFEB3B)
val TradeYellowSurface = Color(0x22FFEB3B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val ConnectedGreen = Color(0xFF10B981)
val ConnectingAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
