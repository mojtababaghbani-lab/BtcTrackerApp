package com.example.data.model

enum class TradeSide {
    BUY,
    SELL
}

data class OrderBookEntry(
    val price: Double,
    val size: Double
)

data class OrderBookData(
    val sequence: String,
    val timestamp: Long,
    val bids: List<OrderBookEntry>,
    val asks: List<OrderBookEntry>,
    val totalBidVolume: Double,
    val totalAskVolume: Double,
    val bestBid: Double,
    val bestAsk: Double,
    val spread: Double,
    val midPrice: Double
)

data class Trade(
    val id: String,
    val price: Double,
    val size: Double,
    val side: TradeSide,
    val timestamp: Long,
    val isWhale: Boolean
)

data class CandleStick(
    val time: Long,      // Start time in seconds (or ms)
    val open: Double,
    val close: Double,
    val high: Double,
    val low: Double,
    val volume: Double,
    val turnover: Double = 0.0,
    val largeTrades: List<Trade> = emptyList() // Trades in this candle with size >= 0.1 BTC
)

enum class ConnectionStatus {
    CONNECTED,
    CONNECTING,
    RECONNECTING,
    OFFLINE
}
