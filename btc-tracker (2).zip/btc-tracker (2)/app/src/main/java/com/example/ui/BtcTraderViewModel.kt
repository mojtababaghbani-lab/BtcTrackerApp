package com.example.ui

import android.app.Application
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.model.CandleStick
import com.example.data.model.ConnectionStatus
import com.example.data.model.OrderBookData
import com.example.data.model.Trade
import com.example.data.network.BinanceRepository
import com.example.service.LiveMarketForegroundService
import com.example.sound.SoundAlertManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

data class BtcTraderUiState(
    val selectedSymbol: String = "BTCUSDT",
    val availableSymbols: List<String> = BinanceRepository.AVAILABLE_SYMBOLS,
    val currentPrice: Double? = null,
    val previousPrice: Double? = null,
    val priceChange24h: Double = 0.0,
    val priceDirection: Int = 0, // +1 up, -1 down, 0 neutral
    val orderBook: OrderBookData? = null,
    val totalBidVolume: Double = 0.0,
    val totalAskVolume: Double = 0.0,
    val recentTrades: List<Trade> = emptyList(),
    val whaleTrades: List<Trade> = emptyList(),
    val candleSticks: List<CandleStick> = emptyList(),
    val isCandlesLoading: Boolean = false,
    val activeWhaleAlert: Trade? = null,
    val connectionStatus: ConnectionStatus = ConnectionStatus.OFFLINE,
    val isSoundEnabled: Boolean = true,
    val isVibrateEnabled: Boolean = true,
    val isBackgroundEnabled: Boolean = true,
    val minTradeDisplayThreshold: Double = 0.01, // Only show trades >= 0.01 in executed trades list
    val whaleThreshold: Double = 0.1, // Alert on trades >= 0.1
    val isRefreshing: Boolean = false,
    val errorMessage: String? = null,
    val selectedTab: TraderTab = TraderTab.ALL_TRADES
)

enum class TraderTab {
    ALL_TRADES,
    WHALE_ALERTS,
    CHART,
    ORDER_BOOK
}

class BtcTraderViewModel(application: Application) : AndroidViewModel(application) {

    private val soundManager = SoundAlertManager(application.applicationContext)
    private val repository = BinanceRepository.getInstance()

    private val _uiState = MutableStateFlow(BtcTraderUiState())
    val uiState: StateFlow<BtcTraderUiState> = _uiState.asStateFlow()

    private var pollJob: Job? = null
    private var candlePollJob: Job? = null
    private var tradeStreamJob: Job? = null
    private var whaleBannerDismissJob: Job? = null

    init {
        // Collect connection status
        viewModelScope.launch {
            repository.connectionStatus.collect { status ->
                _uiState.update { it.copy(connectionStatus = status) }
            }
        }

        // Start background service by default so tracking continues when minimized
        try {
            LiveMarketForegroundService.start(application)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Initialize streams for selected symbol
        initSymbolStreams(_uiState.value.selectedSymbol)
    }

    fun selectSymbol(newSymbol: String) {
        val sym = newSymbol.uppercase()
        if (sym == _uiState.value.selectedSymbol) return

        _uiState.update {
            it.copy(
                selectedSymbol = sym,
                currentPrice = null,
                previousPrice = null,
                orderBook = null,
                recentTrades = emptyList(),
                whaleTrades = emptyList(),
                candleSticks = emptyList(),
                isCandlesLoading = true
            )
        }

        initSymbolStreams(sym)
    }

    private fun initSymbolStreams(symbol: String) {
        tradeStreamJob?.cancel()
        pollJob?.cancel()
        candlePollJob?.cancel()

        // Connect Binance WebSocket
        repository.connectTradeWebSocket(symbol)

        // Collect live WebSocket trades
        tradeStreamJob = viewModelScope.launch {
            repository.tradeFlow.collect { trade ->
                handleIncomingTrade(trade)
            }
        }

        // Start 1-min candles polling
        candlePollJob = viewModelScope.launch {
            _uiState.update { it.copy(isCandlesLoading = true) }
            refreshCandlesNow(symbol)
            while (isActive) {
                delay(12000)
                refreshCandlesNow(symbol)
            }
        }

        // Start OrderBook & Price polling
        pollJob = viewModelScope.launch {
            refreshOrderBookNow(symbol)
            while (isActive) {
                delay(3500)
                refreshOrderBookNow(symbol)
            }
        }
    }

    private suspend fun refreshCandlesNow(symbol: String) {
        val result = repository.fetch1MinCandles(symbol)
        result.onSuccess { fetchedCandles ->
            _uiState.update { state ->
                // Attach any known large trades to their corresponding 1m candle
                val allLargeTrades = (state.whaleTrades + state.recentTrades.filter { it.size >= 0.1 })
                    .distinctBy { it.id }

                val enriched = fetchedCandles.map { candle ->
                    val candleStartSec = candle.time
                    val candleEndSec = candleStartSec + 60
                    val matchingTrades = allLargeTrades.filter { trade ->
                        val tradeSec = trade.timestamp / 1000
                        tradeSec in candleStartSec until candleEndSec
                    }
                    candle.copy(largeTrades = matchingTrades)
                }

                state.copy(
                    candleSticks = enriched,
                    isCandlesLoading = false
                )
            }
        }.onFailure {
            _uiState.update { it.copy(isCandlesLoading = false) }
        }
    }

    private fun handleIncomingTrade(trade: Trade) {
        val currentPrice = _uiState.value.currentPrice
        val direction = when {
            currentPrice == null -> 0
            trade.price > currentPrice -> 1
            trade.price < currentPrice -> -1
            else -> _uiState.value.priceDirection
        }

        // Only include trades with volume >= 0.01 in the executed trades list
        val updatedRecent = if (trade.size >= _uiState.value.minTradeDisplayThreshold) {
            _uiState.value.recentTrades.toMutableList().apply {
                add(0, trade)
                if (size > 120) removeAt(lastIndex)
            }
        } else {
            _uiState.value.recentTrades
        }

        val isWhale = trade.size >= _uiState.value.whaleThreshold
        val updatedWhales = if (isWhale) {
            _uiState.value.whaleTrades.toMutableList().apply {
                add(0, trade)
                if (size > 80) removeAt(lastIndex)
            }
        } else {
            _uiState.value.whaleTrades
        }

        // Real-time update the current active (latest) 1-min candle with this live trade
        val currentCandles = _uiState.value.candleSticks.toMutableList()
        val tradeTimeSec = trade.timestamp / 1000
        val candleBucketSec = (tradeTimeSec / 60) * 60

        if (currentCandles.isNotEmpty()) {
            val lastIdx = currentCandles.size - 1
            val lastCandle = currentCandles[lastIdx]

            if (candleBucketSec >= lastCandle.time) {
                if (candleBucketSec == lastCandle.time) {
                    val newLargeTrades = if (trade.size >= 0.1 && lastCandle.largeTrades.none { it.id == trade.id }) {
                        lastCandle.largeTrades + trade
                    } else {
                        lastCandle.largeTrades
                    }

                    currentCandles[lastIdx] = lastCandle.copy(
                        close = trade.price,
                        high = max(lastCandle.high, trade.price),
                        low = min(lastCandle.low, trade.price),
                        volume = lastCandle.volume + trade.size,
                        largeTrades = newLargeTrades
                    )
                } else {
                    val newLarge = if (trade.size >= 0.1) listOf(trade) else emptyList()
                    val newCandle = CandleStick(
                        time = candleBucketSec,
                        open = trade.price,
                        close = trade.price,
                        high = trade.price,
                        low = trade.price,
                        volume = trade.size,
                        largeTrades = newLarge
                    )
                    currentCandles.add(newCandle)
                    if (currentCandles.size > 80) {
                        currentCandles.removeAt(0)
                    }
                }
            }
        } else {
            val newLarge = if (trade.size >= 0.1) listOf(trade) else emptyList()
            currentCandles.add(
                CandleStick(
                    time = candleBucketSec,
                    open = trade.price,
                    close = trade.price,
                    high = trade.price,
                    low = trade.price,
                    volume = trade.size,
                    largeTrades = newLarge
                )
            )
        }

        _uiState.update { state ->
            state.copy(
                currentPrice = trade.price,
                previousPrice = currentPrice ?: trade.price,
                priceDirection = direction,
                recentTrades = updatedRecent,
                whaleTrades = updatedWhales,
                candleSticks = currentCandles,
                activeWhaleAlert = if (isWhale) trade else state.activeWhaleAlert
            )
        }

        if (isWhale) {
            triggerWhaleAlert(trade)
        }
    }

    private fun triggerWhaleAlert(trade: Trade) {
        if (_uiState.value.isSoundEnabled) {
            soundManager.playWhaleAlert(vibrate = _uiState.value.isVibrateEnabled)
        }

        whaleBannerDismissJob?.cancel()
        whaleBannerDismissJob = viewModelScope.launch {
            delay(8000)
            _uiState.update { state ->
                if (state.activeWhaleAlert?.id == trade.id) {
                    state.copy(activeWhaleAlert = null)
                } else state
            }
        }
    }

    fun manualRefresh() {
        val symbol = _uiState.value.selectedSymbol
        viewModelScope.launch {
            refreshOrderBookNow(symbol)
            refreshCandlesNow(symbol)
        }
    }

    private suspend fun refreshOrderBookNow(symbol: String) {
        _uiState.update { it.copy(isRefreshing = true) }
        val result = repository.fetchOrderBook(symbol)
        result.onSuccess { data ->
            _uiState.update { state ->
                val fallbackPrice = state.currentPrice ?: data.bestBid.takeIf { it > 0 } ?: data.midPrice
                state.copy(
                    orderBook = data,
                    totalBidVolume = data.totalBidVolume,
                    totalAskVolume = data.totalAskVolume,
                    currentPrice = state.currentPrice ?: fallbackPrice,
                    isRefreshing = false,
                    errorMessage = null
                )
            }
        }.onFailure { error ->
            _uiState.update { state ->
                state.copy(
                    isRefreshing = false,
                    errorMessage = error.localizedMessage ?: "Network Error"
                )
            }
        }
    }

    fun toggleSound() {
        _uiState.update { it.copy(isSoundEnabled = !it.isSoundEnabled) }
    }

    fun toggleVibration() {
        _uiState.update { it.copy(isVibrateEnabled = !it.isVibrateEnabled) }
    }

    fun toggleBackgroundMode() {
        val newState = !_uiState.value.isBackgroundEnabled
        _uiState.update { it.copy(isBackgroundEnabled = newState) }
        if (newState) {
            LiveMarketForegroundService.start(getApplication())
        } else {
            LiveMarketForegroundService.stop(getApplication())
        }
    }

    fun selectTab(tab: TraderTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun dismissWhaleBanner() {
        _uiState.update { it.copy(activeWhaleAlert = null) }
    }

    fun testSoundAlert() {
        soundManager.playTestAlert()
        // Also trigger a sample heads-up notification so user can verify home screen popup
        val context = getApplication<Application>()
        val testNotification = NotificationCompat.Builder(context, LiveMarketForegroundService.ALERTS_CHANNEL_ID)
            .setContentTitle("🚨 تست هشدار نوتیفیکیشن روی صفحه")
            .setContentText("این پیام به صورت پاپ‌آپ روی صفحه اصلی و قفل نمایش داده می‌شود (شکار نهنگ)")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVibrate(longArrayOf(0, 300, 150, 300))
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(LiveMarketForegroundService.ALERT_NOTIFICATION_ID, testNotification)
    }

    fun reconnect() {
        initSymbolStreams(_uiState.value.selectedSymbol)
    }

    override fun onCleared() {
        super.onCleared()
        // If background mode is disabled, close websocket and stop service
        if (!_uiState.value.isBackgroundEnabled) {
            repository.closeWebSocket()
            LiveMarketForegroundService.stop(getApplication())
        }
        soundManager.release()
    }
}
