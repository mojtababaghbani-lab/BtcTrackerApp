package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CandleStick
import com.example.data.model.Trade
import com.example.data.model.TradeSide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Dark Spot Trading Theme Colors
private val ChartBg = Color(0xFF12151C)
private val ChartSurface = Color(0xFF1B1E28)
private val ChartCardBorder = Color(0xFF262B38)
private val ChartGridColor = Color(0xFF1E2330)
private val ChartBuyGreen = Color(0xFF00C087)
private val ChartSellRed = Color(0xFFFF4D4F)
private val ChartBrandAccent = Color(0xFFF3BA2F)
private val ChartTextPrimary = Color(0xFFF1F3F5)
private val ChartTextMuted = Color(0xFF7A8394)
private val ChartCrosshair = Color(0xFF535A6B)

/**
 * High-performance, crash-proof 1-Minute Candlestick Chart.
 *
 * Features:
 * 1. 1-Minute Kline candles with High/Low wicks and Open/Close bodies.
 * 2. Visual dots for trades >= 0.1:
 *    - Green dot (#00C087) for BUY trades
 *    - Red dot (#FF4D4F) for SELL trades
 * 3. 2-Minute Retention Rule:
 *    - Dots remain active and visible on the chart for 120 seconds from their execution time.
 * 4. Interactive Click:
 *    - Tap any dot on the chart or bottom strip to view exact price, size, USD value, and time.
 * 5. Stable, leak-free, non-crashing: zero snapshot state writes during DrawScope.
 */
@Composable
fun Btc1MinCandlestickChart(
    candles: List<CandleStick>,
    trades: List<Trade>,
    currentPrice: Double?,
    isLoading: Boolean,
    modifier: Modifier = Modifier,
    symbolName: String = "BTC/USDT"
) {
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var selectedTradePopup by remember { mutableStateOf<Trade?>(null) }
    var inspectedCandle by remember { mutableStateOf<CandleStick?>(null) }
    var crosshairOffset by remember { mutableStateOf<Offset?>(null) }
    var candleDisplayCount by remember { mutableIntStateOf(40) }

    // Heartbeat ticker to prune trades older than 2 minutes (120 seconds) in real time
    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMs = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000)
        }
    }

    // Filter trades >= 0.1 that are younger than 2 minutes (120,000 ms)
    val twoMinutesMs = 2 * 60 * 1000L
    val activeLargeTrades = remember(trades, currentTimeMs) {
        trades.filter { trade ->
            trade.size >= 0.1 && (currentTimeMs - trade.timestamp) in 0..twoMinutesMs
        }
    }

    val displayCandles = remember(candles, candleDisplayCount) {
        if (candles.isNotEmpty()) candles.takeLast(candleDisplayCount) else emptyList()
    }

    val lastCandle = displayCandles.lastOrNull()
    val activeCandle = inspectedCandle ?: lastCandle

    // Price change calculations
    val firstCandle = displayCandles.firstOrNull()
    val priceDiff = if (lastCandle != null && firstCandle != null) lastCandle.close - firstCandle.open else 0.0
    val isBullish = priceDiff >= 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ChartBg)
            .testTag("candlestick_chart_container")
    ) {
        // --------------------------------------------------------------------
        // 1. Header Bar: Pair, Live Price, 2-Min Dot Legend
        // --------------------------------------------------------------------
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ChartSurface)
                    .border(1.dp, ChartCardBorder)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pair & Live Price
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ChartBrandAccent.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = symbolName,
                            color = ChartBrandAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val dispPrice = currentPrice ?: lastCandle?.close
                    Text(
                        text = if (dispPrice != null && dispPrice > 0) String.format(Locale.US, "$%,.2f", dispPrice) else "$--,--",
                        color = if (isBullish) ChartBuyGreen else ChartSellRed,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Timeframe pill + 2-Min Live Large Trades Legend
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ChartBg)
                            .border(1.dp, ChartBrandAccent.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "۱ دقیقه (1M)",
                            color = ChartBrandAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Dot Indicator Legend
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ChartBg)
                            .border(1.dp, ChartCardBorder, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(ChartBuyGreen)
                            )
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(ChartSellRed)
                            )
                            Text(
                                text = "نقاط ۲ دقیقه‌ای",
                                color = ChartTextPrimary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // --------------------------------------------------------------------
        // 2. Interactive Click Popup (Modal for trade >= 0.1)
        // --------------------------------------------------------------------
        AnimatedVisibility(
            visible = selectedTradePopup != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            selectedTradePopup?.let { trade ->
                val isBuy = trade.side == TradeSide.BUY
                val dotColor = if (isBuy) ChartBuyGreen else ChartSellRed
                val timeRemainingSec = max(0L, (twoMinutesMs - (currentTimeMs - trade.timestamp)) / 1000)
                val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(trade.timestamp))
                val usdValue = trade.price * trade.size

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ChartSurface)
                        .border(1.5.dp, dotColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(dotColor.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(dotColor)
                                    )
                                }

                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = if (isBuy) "معامله خرید (BUY) 🟢" else "معامله فروش (SELL) 🔴",
                                            color = dotColor,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(dotColor.copy(alpha = 0.15f))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "${timeRemainingSec}s مانده",
                                                color = ChartTextMuted,
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    Text(
                                        text = String.format(
                                            Locale.US,
                                            "حجم: %.4f | قیمت: $%,.2f | ارزش: $%,.0f | زمان: %s",
                                            trade.size, trade.price, usdValue, timeStr
                                        ),
                                        color = ChartTextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            IconButton(
                                onClick = { selectedTradePopup = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = ChartTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // --------------------------------------------------------------------
        // 3. OHLC Strip (Open, High, Low, Close, Volume)
        // --------------------------------------------------------------------
        if (activeCandle != null) {
            val c = activeCandle
            val isBull = c.close >= c.open
            val col = if (isBull) ChartBuyGreen else ChartSellRed
            val timeFmt = SimpleDateFormat("HH:mm", Locale.US).format(Date(c.time * 1000))

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ChartBg)
                        .padding(horizontal = 10.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeFmt,
                        color = ChartTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "O: ${String.format(Locale.US, "%,.1f", c.open)}",
                        color = ChartTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "H: ${String.format(Locale.US, "%,.1f", c.high)}",
                        color = ChartBuyGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "L: ${String.format(Locale.US, "%,.1f", c.low)}",
                        color = ChartSellRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "C: ${String.format(Locale.US, "%,.1f", c.close)}",
                        color = col,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "V: ${String.format(Locale.US, "%.2f", c.volume)}",
                        color = ChartTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // --------------------------------------------------------------------
        // 4. Candlestick Canvas Area
        // --------------------------------------------------------------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(ChartBg)
                .padding(horizontal = 4.dp)
        ) {
            if (displayCandles.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            color = ChartBrandAccent,
                            modifier = Modifier.size(30.dp),
                            strokeWidth = 2.5.dp
                        )
                        Text(
                            text = if (isLoading) "در حال بارگذاری اطلاعات کندل‌های ۱ دقیقه‌ای..." else "در حال دریافت داده‌های اولیه چارت...",
                            color = ChartTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                val density = LocalDensity.current
                val rightAxisWidth = 68.dp
                val volumePaneHeight = 36.dp
                val timeAxisHeight = 18.dp

                val rightPadPx = with(density) { rightAxisWidth.toPx() }
                val volHPx = with(density) { volumePaneHeight.toPx() }
                val bottomPadPx = with(density) { timeAxisHeight.toPx() }
                val topPadPx = 10f
                val leftPadPx = 6f

                val validLows = displayCandles.map { it.low }.filter { it > 0 }
                val validHighs = displayCandles.map { it.high }.filter { it > 0 }

                val rawMin = if (validLows.isNotEmpty()) validLows.minOrNull() ?: 100.0 else 100.0
                val rawMax = if (validHighs.isNotEmpty()) validHighs.maxOrNull() ?: 200.0 else 200.0

                val minPrice = rawMin * 0.9997
                val maxPrice = rawMax * 1.0003
                val priceRange = max(1.0, maxPrice - minPrice)
                val maxVolume = max(0.1, displayCandles.maxOfOrNull { it.volume } ?: 1.0)

                val startTimeSec = displayCandles.firstOrNull()?.time ?: 0L
                val endTimeSec = (displayCandles.lastOrNull()?.time ?: 0L) + 60L
                val totalSpanSec = max(60L, endTimeSec - startTimeSec)

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(displayCandles, activeLargeTrades) {
                            detectTapGestures { tapOffset ->
                                val w = size.width.toFloat()
                                val h = size.height.toFloat()
                                val chartW = max(10f, w - leftPadPx - rightPadPx)
                                val chartH = max(10f, h - topPadPx - bottomPadPx - volHPx)

                                // 1. Check if user clicked on any large trade dot
                                var matchedTrade: Trade? = null
                                for (lt in activeLargeTrades) {
                                    val tradeSec = lt.timestamp / 1000L
                                    val relX = if (totalSpanSec > 0 && tradeSec >= startTimeSec) {
                                        ((tradeSec - startTimeSec).toFloat() / totalSpanSec.toFloat()) * chartW
                                    } else {
                                        chartW - 10f
                                    }
                                    val dotX = (leftPadPx + relX).coerceIn(leftPadPx, w - rightPadPx - 4f)
                                    val dotY = topPadPx + chartH * (1f - ((lt.price - minPrice) / priceRange).toFloat())
                                        .coerceIn(0f, 1f)

                                    val dx = tapOffset.x - dotX
                                    val dy = tapOffset.y - dotY
                                    if (sqrt((dx * dx + dy * dy).toDouble()) <= 28.0) {
                                        matchedTrade = lt
                                        break
                                    }
                                }

                                if (matchedTrade != null) {
                                    selectedTradePopup = matchedTrade
                                } else {
                                    // Crosshair position & inspected candle
                                    crosshairOffset = tapOffset
                                    if (displayCandles.isNotEmpty()) {
                                        val slot = chartW / displayCandles.size.coerceAtLeast(1)
                                        val idx = ((tapOffset.x - leftPadPx) / slot).toInt()
                                            .coerceIn(0, (displayCandles.size - 1).coerceAtLeast(0))
                                        inspectedCandle = displayCandles.getOrNull(idx)
                                    }
                                }
                            }
                        }
                        .pointerInput(displayCandles) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    crosshairOffset = offset
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    crosshairOffset = change.position
                                    val w = size.width.toFloat()
                                    val chartW = max(10f, w - leftPadPx - rightPadPx)
                                    if (displayCandles.isNotEmpty()) {
                                        val slot = chartW / displayCandles.size.coerceAtLeast(1)
                                        val idx = ((change.position.x - leftPadPx) / slot).toInt()
                                            .coerceIn(0, (displayCandles.size - 1).coerceAtLeast(0))
                                        inspectedCandle = displayCandles.getOrNull(idx)
                                    }
                                },
                                onDragEnd = {},
                                onDragCancel = {
                                    crosshairOffset = null
                                    inspectedCandle = null
                                }
                            )
                        }
                ) {
                    val width = size.width
                    val height = size.height

                    val chartW = max(10f, width - leftPadPx - rightPadPx)
                    val chartH = max(10f, height - topPadPx - bottomPadPx - volHPx)

                    // A. Gridlines
                    val gridLines = 5
                    for (i in 0..gridLines) {
                        val y = topPadPx + chartH * (i.toFloat() / gridLines)
                        drawLine(
                            color = ChartGridColor,
                            start = Offset(leftPadPx, y),
                            end = Offset(width - rightPadPx, y),
                            strokeWidth = 1f
                        )
                    }

                    // Volume baseline separator
                    drawLine(
                        color = ChartCardBorder,
                        start = Offset(leftPadPx, topPadPx + chartH),
                        end = Offset(width - rightPadPx, topPadPx + chartH),
                        strokeWidth = 1.2f
                    )

                    val candleCount = displayCandles.size.coerceAtLeast(1)
                    val slot = chartW / candleCount
                    val candleBodyW = max(2.5f, slot * 0.72f)

                    // B. Draw Candles and Volume Bars
                    displayCandles.forEachIndexed { index, candle ->
                        val centerX = leftPadPx + (index * slot) + (slot / 2f)
                        val isBull = candle.close >= candle.open
                        val color = if (isBull) ChartBuyGreen else ChartSellRed

                        // 1. Volume bar at bottom
                        val volRatio = (candle.volume / maxVolume).toFloat().coerceIn(0.04f, 1f)
                        val barH = volRatio * (volHPx - 4f)
                        val barTop = topPadPx + chartH + (volHPx - barH)
                        drawRect(
                            color = color.copy(alpha = 0.38f),
                            topLeft = Offset(centerX - (candleBodyW / 2f), barTop),
                            size = Size(candleBodyW, barH)
                        )

                        // 2. Candlestick
                        val highY = topPadPx + chartH * (1f - ((candle.high - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)
                        val lowY = topPadPx + chartH * (1f - ((candle.low - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)
                        val openY = topPadPx + chartH * (1f - ((candle.open - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)
                        val closeY = topPadPx + chartH * (1f - ((candle.close - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)

                        val bodyTop = min(openY, closeY)
                        val bodyBottom = max(openY, closeY)
                        val bodyHeight = max(2f, bodyBottom - bodyTop)

                        // Wick
                        drawLine(
                            color = color,
                            start = Offset(centerX, highY),
                            end = Offset(centerX, lowY),
                            strokeWidth = 1.3f
                        )

                        // Body
                        drawRect(
                            color = color,
                            topLeft = Offset(centerX - (candleBodyW / 2f), bodyTop),
                            size = Size(candleBodyW, bodyHeight)
                        )
                    }

                    // C. DRAW CLICKABLE DOTS FOR TRADES >= 0.1 (GREEN FOR BUY, RED FOR SELL, 2 MINUTES RETENTION)
                    activeLargeTrades.forEach { lt ->
                        val tradeSec = lt.timestamp / 1000L
                        val relX = if (totalSpanSec > 0 && tradeSec >= startTimeSec) {
                            ((tradeSec - startTimeSec).toFloat() / totalSpanSec.toFloat()) * chartW
                        } else {
                            chartW - (slot / 2f)
                        }
                        val dotX = (leftPadPx + relX).coerceIn(leftPadPx, width - rightPadPx - 4f)
                        val dotY = topPadPx + chartH * (1f - ((lt.price - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)
                        val dotCenter = Offset(dotX, dotY)

                        val isBuy = lt.side == TradeSide.BUY
                        val dotColor = if (isBuy) ChartBuyGreen else ChartSellRed

                        // Outer Glow Ring
                        drawCircle(
                            color = dotColor.copy(alpha = 0.28f),
                            radius = 11f,
                            center = dotCenter
                        )
                        // Mid Ring
                        drawCircle(
                            color = dotColor.copy(alpha = 0.65f),
                            radius = 7.5f,
                            center = dotCenter
                        )
                        // Solid Core
                        drawCircle(
                            color = dotColor,
                            radius = 4.5f,
                            center = dotCenter
                        )
                        // White Center Highlight
                        drawCircle(
                            color = Color.White,
                            radius = 1.8f,
                            center = dotCenter
                        )
                    }

                    // D. Current Price Dashed Line
                    lastCandle?.let { lc ->
                        val currentY = topPadPx + chartH * (1f - ((lc.close - minPrice) / priceRange).toFloat()).coerceIn(0f, 1f)
                        val lastColor = if (lc.close >= lc.open) ChartBuyGreen else ChartSellRed

                        drawLine(
                            color = lastColor.copy(alpha = 0.85f),
                            start = Offset(leftPadPx, currentY),
                            end = Offset(width - rightPadPx, currentY),
                            strokeWidth = 1.2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f))
                        )

                        // Right axis badge
                        drawRect(
                            color = lastColor,
                            topLeft = Offset(width - rightPadPx, currentY - 8f),
                            size = Size(rightPadPx, 16f)
                        )
                    }

                    // E. Crosshair
                    crosshairOffset?.let { ch ->
                        val chX = ch.x.coerceIn(leftPadPx, width - rightPadPx)
                        val chY = ch.y.coerceIn(topPadPx, topPadPx + chartH + volHPx)

                        // Vertical
                        drawLine(
                            color = ChartCrosshair,
                            start = Offset(chX, topPadPx),
                            end = Offset(chX, topPadPx + chartH + volHPx),
                            strokeWidth = 0.9f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                        )

                        // Horizontal
                        drawLine(
                            color = ChartCrosshair,
                            start = Offset(leftPadPx, chY),
                            end = Offset(width - rightPadPx, chY),
                            strokeWidth = 0.9f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                        )
                    }
                }

                // Price Scale on the right
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopEnd
                    ) {
                        Column(
                            modifier = Modifier
                                .width(rightAxisWidth)
                                .fillMaxSize()
                                .padding(top = 8.dp, bottom = volumePaneHeight + timeAxisHeight + 4.dp, end = 4.dp),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.End
                        ) {
                            for (i in 0..5) {
                                val p = maxPrice - (priceRange * (i.toFloat() / 5))
                                Text(
                                    text = String.format(Locale.US, "%,.1f", p),
                                    color = ChartTextMuted,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // --------------------------------------------------------------------
        // 5. Bottom Horizontal Strip of Active 2-Minute Dots
        // --------------------------------------------------------------------
        if (activeLargeTrades.isNotEmpty()) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ChartSurface)
                        .border(1.dp, ChartCardBorder)
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "نقاط فعال روی چارت (۲ دقیقه):",
                            color = ChartTextMuted,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "${activeLargeTrades.size} معامله",
                            color = ChartBrandAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        itemsIndexed(
                            items = activeLargeTrades.take(6),
                            key = { index, lt -> "${lt.id}_${lt.timestamp}_$index" }
                        ) { _, lt ->
                            val isBuy = lt.side == TradeSide.BUY
                            val dotColor = if (isBuy) ChartBuyGreen else ChartSellRed
                            val remainingSec = max(0L, (twoMinutesMs - (currentTimeMs - lt.timestamp)) / 1000)

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ChartBg)
                                    .border(1.dp, dotColor.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                                    .clickable { selectedTradePopup = lt }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(dotColor)
                                    )
                                    Text(
                                        text = "%.3f".format(Locale.US, lt.size),
                                        color = dotColor,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${remainingSec}s",
                                        color = ChartTextMuted,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
